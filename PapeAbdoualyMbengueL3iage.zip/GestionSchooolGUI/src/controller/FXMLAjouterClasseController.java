/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import modeles.Classe;
import services.Ischoool;
import services.SchoolServiceBD;

/**
 * FXML Controller class
 *
 * @author user
 */
public class FXMLAjouterClasseController implements Initializable {

    @FXML
    private TextField txtLibelle;
    @FXML
    private Button BtnAjouter;
    @FXML
    private TableView<Classe> tblvClasse;
    @FXML
    private TableColumn<Classe, Integer> tblcId;
    @FXML
    private TableColumn<Classe, String> tblcLibelle;
    
    private Ischoool service; //1
    ObservableList<Classe> obClasses; //4
    private Classe c= new Classe(); //9
    
 
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        service= new SchoolServiceBD(); //2
        ArrayList<Classe> classes = service.listerClasse(); //3
        
        obClasses=FXCollections.observableArrayList(classes);  //5
        tblcId.setCellValueFactory(new PropertyValueFactory<>("id")); // 6
        tblcLibelle.setCellValueFactory(new PropertyValueFactory<>("libelle")); // 7
        
        tblvClasse.setItems(obClasses); // rattacher la source de données à l'observable  //8
    }    

    @FXML
    private void handleAjouter(ActionEvent event) {
        if(c!=null){
            c=new Classe();
            c.setLibelle(txtLibelle.getText());
        }else{
               txtLibelle.setText("");
        }
        service.ajouterClasse(c);
        obClasses.add(c);
    }
    
}
