/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import static javafx.collections.FXCollections.observableList;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import modeles.Assembleur;
import modeles.Classe;
import modeles.Etudiant;
import modeles.Inscription;
import modeles.Personne;
import services.Ischoool;
import services.SchoolServiceBD;

/**
 * FXML Controller class
 *
 * @author user
 */
public class FXMLInscriptionController implements Initializable {

    @FXML
    private TextField txtNumero;
    @FXML
    private TextField txtTuteur;
    @FXML
    private TextField txtNom;
    @FXML
    private TextField txtPrenom;
    @FXML
    private TextField txtDateNaissance;
    @FXML
    private Button BtnOk;
    @FXML
    
    private ComboBox<Classe> cboClasse;
    @FXML
    private ComboBox<String> cboAnneeScolaire;
    @FXML
    private Button BtnInscrire;
    @FXML
    private ComboBox<String> cboFiltreAnnee;
    @FXML
    private ComboBox<Classe> cboFiltreClasse;
    @FXML
    private TableView<Assembleur> tblvInscription;
    @FXML
    private TableColumn<Assembleur, String> tblcNom;
    @FXML
    private TableColumn<Assembleur, String> tblcPrenom;
    @FXML
    private TableColumn<Assembleur, Classe> tblcClasse;  // revoir
    @FXML
    private TableColumn<Assembleur, String> tblcAnneeScolaire;

    /**
     * Initializes the controller class.
     */
    
        private Ischoool service; // ce changement est fait lorsqu'on quitte  liste pour bd 1
        private Etudiant etu = new Etudiant();
         ObservableList<Classe> obClasses; 
         ObservableList<Assembleur> obAssembleur; 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        service= new SchoolServiceBD (); 
               
       cboAnneeScolaire.getItems().add("2013-2014");
       cboAnneeScolaire.getItems().add("2014-2015");
       cboAnneeScolaire.getItems().add("2015-2016");
       cboAnneeScolaire.getItems().add("2016-2017");
       
       cboFiltreAnnee.getItems().add("2013-2014");
       cboFiltreAnnee.getItems().add("2014-2015");
       cboFiltreAnnee.getItems().add("2015-2016");
       cboFiltreAnnee.getItems().add("2016-2017");
       
       ArrayList<Classe> ListClass = service.listerClasse();
       obClasses= FXCollections.observableArrayList(ListClass);
       cboClasse.setItems(obClasses);
       cboFiltreClasse.setItems(obClasses);
       
       //ArrayList<Etudiant> elementsEtu = service.listerEtudiant();
       
      //obAssembleur=FXCollections.observableArrayList(elementsEtu); // afficher les éléments dans le tableau 3
       tblcNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
       tblcPrenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
       tblcClasse.setCellValueFactory(new PropertyValueFactory<>("classe"));
       tblcAnneeScolaire.setCellValueFactory(new PropertyValueFactory<>("anneeScolaire"));
       
       
       tblvInscription.setItems(obAssembleur); // rattacher la source de données à l'observable
       
       
    }    

    @FXML
    private void handleActiveSearchByNum(ActionEvent event) {
        String numero=txtNumero.getText();     // rechercher etudiant par numero 
        etu= service.RechercherEtudiant(numero);
        if (etu != null){
            txtNom.setText(etu.getNom());
            txtPrenom.setText(etu.getPrenom());
            
            txtTuteur.setText(etu.getTuteur());
            
        }else{
            txtNom.setText("");
            txtPrenom.setText("");
            txtTuteur.setText("");
        }
    }

    @FXML
    private void handleInscrire(ActionEvent event) throws Exception {
        String numero= txtNumero.getText();
        String nom= txtNom.getText();
        String prenom=txtPrenom.getText();
        
        String tuteur= txtTuteur.getText();
        
        
        etu.setNumero(numero);
        etu.setNom(nom);
        etu.setPrenom(prenom);
        etu.setTuteur(tuteur);
        etu.setType("etudiant");
        
        String classe= cboClasse.getValue().toString();
        String annee= cboAnneeScolaire.getValue();
        Classe cl = service.rechercherClasseParLibelle(classe);
        
        int ok=0;
        
        //ok=service.AjouterEtudiant(etu);
        
        if(ok>0){
            Inscription ic = new Inscription();
            ic.setAnneeScol(annee);
            ic.setClasse(cl);
            //ic.setDate("");
            
            Etudiant etu = service.RechercherEtudiantById(ok);
           
        }
        obAssembleur=FXCollections.observableArrayList(service.listerAssembleur());
              tblvInscription.setItems(obAssembleur);
    }
      
             
       
       
        
        
}
