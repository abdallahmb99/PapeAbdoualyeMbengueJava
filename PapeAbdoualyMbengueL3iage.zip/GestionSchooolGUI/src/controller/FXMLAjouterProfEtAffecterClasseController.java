/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import modeles.Classe;
import modeles.Professeur;
import services.Ischoool;
import services.SchoolServiceBD;

/**
 * FXML Controller class
 *
 * @author user
 */
public class FXMLAjouterProfEtAffecterClasseController implements Initializable {

    @FXML
    private TextField txtNumero;
    @FXML
    private TextField txtNom;
    @FXML
    private TextField txtPrenom;
    @FXML
    private TextField txtDateNaissance;
    @FXML
    private TextField txtGrade;
    @FXML
    private Button BtnOk;
    @FXML
    private ComboBox<String> cboAnnee;
    @FXML
    private ComboBox<Classe> cboClasse;
    @FXML
    private TableView<Classe> tblvClasseEnseigne;
    @FXML
    private TableColumn<Classe, String> tblcLibelle;
    @FXML
    private Button BtnEnregistrer;

    /**
     * Initializes the controller class.
     */
     private Ischoool service; // ce changement est fait lorsqu'on quitte  liste pour bd 1
     private Professeur pro = new Professeur();
     ObservableList<Classe> obClasses; 
     
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        service= new SchoolServiceBD (); 
                
       cboAnnee.getItems().add("2013-2014");
       cboAnnee.getItems().add("2014-2015");
       cboAnnee.getItems().add("2015-2016");
       cboAnnee.getItems().add("2016-2017");
       
       ArrayList<Classe> ListClass = service.listerClasse();
       obClasses= FXCollections.observableArrayList(ListClass);
       cboClasse.setItems(obClasses);
       
    }    

    @FXML
    private void handleSearchByNum(ActionEvent event) {
         String numero=txtNumero.getText();     // rechercher etudiant par numero 
        pro= service.rechercherProfesseur(numero);
        if (pro != null){
            txtNom.setText(pro.getNom());
            txtPrenom.setText(pro.getPrenom());
            
            txtGrade.setText(pro.getGrade());
            
        }else{
            txtNom.setText("");
            txtPrenom.setText("");
            txtGrade.setText("");
        }
    }
    
}
