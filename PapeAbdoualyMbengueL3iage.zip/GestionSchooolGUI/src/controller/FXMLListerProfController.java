/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import modeles.Professeur;
import services.Ischoool;
import services.SchoolServiceBD;

/**
 * FXML Controller class
 *
 * @author user
 */
public class FXMLListerProfController implements Initializable {

    @FXML
    private TextField txtNumero;
    @FXML
    private Button BtnOk;
    @FXML
    private TableView<Professeur> tblvProfesseur;
    @FXML
    private TableColumn<Professeur, String> tblcNom;
    @FXML
    private TableColumn<Professeur, String> tblcPrenom;
    @FXML
    
    
    private ComboBox<Professeur> cboAnnee;
    @FXML
    private TableColumn<Professeur, String> tblcClasse;

    private Ischoool service; //1
     ObservableList<Professeur> obProfesseurs; //4
     
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        service= new SchoolServiceBD(); //2
        ArrayList<Professeur> professeurs = service.listerProfesseur(); //3
        
        obProfesseurs=FXCollections.observableArrayList(professeurs);  //5
        tblcNom.setCellValueFactory(new PropertyValueFactory<>("nom")); // 6
        tblcPrenom.setCellValueFactory(new PropertyValueFactory<>("prenom")); // 7
        
        tblvProfesseur.setItems(obProfesseurs); // rattacher la source de données à l'observable  //8
    }    

    @FXML
    private void handleByNum(ActionEvent event) {
        
    }
    
}
