/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import modeles.Etudiant;
import modeles.Professeur;

/**
 *
 * @author user
 */
public class ProfesseurDao implements IDao<Professeur> {
    
        private MysqlDB mysql;
     
     private final String SQL_INSERT="INSERT INTO `personne` (`id`, `nom`, `prenom`, `datenaissance`, `numero`, `type`, `tuteur`, `grade`) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?);";
     private final String SQL_BY_NUM="Select * From Personne where numero =? ";
      private final String SQL_ALL="Select * From personne ";

     public ProfesseurDao() {
        mysql=new MysqlDB();
    }

    @Override
    public int create(Professeur obj) {
         int result=0;
        try {
              mysql.initPS(SQL_INSERT);
              mysql.getPstm().setString(1, obj.getNom());
              mysql.getPstm().setString(2, obj.getPrenom());
              mysql.getPstm().setDate(3, null);
              mysql.getPstm().setString(4,obj.getNumero());
              mysql.getPstm().setString(5,obj.getType());
              mysql.getPstm().setString(7,obj.getGrade());
            
             
             //5 Execution de la requete
              result=mysql.executeMaj();
             
        } catch (SQLException ex) {
            Logger.getLogger(ProfesseurDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return result;
    }

    @Override
    public boolean update(Professeur obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Professeur> selectAll() {
         ArrayList<Professeur> professeurs= null;
         try {
             professeurs=new ArrayList<Professeur>(); 
            //PreparedStatement ps = cnx.prepareStatement(requete);
            mysql.initPS(SQL_ALL);
            ResultSet rs = mysql.executeSelect();
             while(rs.next()){
                Professeur professeur=new Professeur() ;
                
                professeur.setNom(rs.getString("nom"));
                professeur.setPrenom(rs.getString("prenom"));
                
               professeurs.add(professeur);
            }
         } catch (SQLException ex) {
             Logger.getLogger(ProfesseurDao.class.getName()).log(Level.SEVERE, null, ex);
         }
         return professeurs;

    }

    @Override
    public Professeur selectByNumero(String numero) {
        try {
            //PreparedStatement ps = cnx.prepareStatement(requete);
            mysql.initPS(SQL_BY_NUM);
            //ps.setString(1, numero);
            mysql.getPstm().setString(1, numero);
            ResultSet rs = mysql.executeSelect();
            if(rs.first()){
                Professeur pro = new Professeur();
                pro.setId(rs.getInt("id"));
                pro.setNom(rs.getString("nom"));
                pro.setPrenom(rs.getString("prenom"));
                pro.setDatenaiss(rs.getDate("datenaissance"));
                pro.setNumero(rs.getString("numero"));
                pro.setType(rs.getString("type"));
                pro.setGrade(rs.getString("grade"));
                return pro;
            }
          
        } catch (SQLException ex) {
            Logger.getLogger(ProfesseurDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }

    @Override
    public Professeur selectByDate(Date annee) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    @Override
    public Professeur selectByLibelle(String libelle) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
