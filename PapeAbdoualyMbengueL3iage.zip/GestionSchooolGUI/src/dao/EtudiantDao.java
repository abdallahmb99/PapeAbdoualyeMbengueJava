/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import modeles.Etudiant;

/**
 *
 * @author user
 */
public class EtudiantDao implements IDao<Etudiant> {
       
        private MysqlDB mysql;
        
        private final String SQL_BY_NUM="Select * From Personne where numero =? ";
        private final String SQL_INSERT="INSERT INTO `personne` (`id`, `nom`, `prenom`, `datenaissance`, `numero`, `type`, `tuteur`, `grade`) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?);";
        private final String SQL_ALL="Select * From personne ";
        
    public EtudiantDao() {
        mysql= new MysqlDB();
    }
        
        

    @Override
    public int create(Etudiant obj) {
         int result=0;
        try {
              mysql.initPS(SQL_INSERT);
              mysql.getPstm().setString(1, obj.getNom());
              mysql.getPstm().setString(2, obj.getPrenom());
              mysql.getPstm().setDate(3, null);
              mysql.getPstm().setString(4,obj.getNumero());
              mysql.getPstm().setString(5,obj.getType());
              mysql.getPstm().setString(6,obj.getTuteur());
            
             
             //5 Execution de la requete
              result=mysql.executeMaj();
             
        } catch (SQLException ex) {
            Logger.getLogger(EtudiantDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return result;
    }

    @Override
    public boolean update(Etudiant obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Etudiant> selectAll() {
         ArrayList<Etudiant> etudiants= null;
         try {
             etudiants=new ArrayList<Etudiant>(); 
            //PreparedStatement ps = cnx.prepareStatement(requete);
            mysql.initPS(SQL_ALL);
            ResultSet rs = mysql.executeSelect();
             while(rs.next()){
                Etudiant etudiant=new Etudiant() ;
                
                etudiant.setNom(rs.getString("nom"));
                etudiant.setPrenom(rs.getString("prenom"));
                
               etudiants.add(etudiant);
            }
         } catch (SQLException ex) {
             Logger.getLogger(EtudiantDao.class.getName()).log(Level.SEVERE, null, ex);
         }
         return etudiants;
    }

    @Override
    public Etudiant selectByNumero(String numero) {
       try {
            //PreparedStatement ps = cnx.prepareStatement(requete);
            mysql.initPS(SQL_BY_NUM);
            //ps.setString(1, numero);
            mysql.getPstm().setString(1, numero);
            ResultSet rs = mysql.executeSelect();
            if(rs.first()){
                Etudiant Etudian = new Etudiant();
                Etudian.setId(rs.getInt("id"));
                Etudian.setNom(rs.getString("nom"));
                Etudian.setPrenom(rs.getString("prenom"));
                Etudian.setDatenaiss(rs.getDate("datenaissance"));
                Etudian.setNumero(rs.getString("numero"));
                Etudian.setType(rs.getString("type"));
                Etudian.setTuteur(rs.getString("tuteur"));
                return Etudian;
            }
          
        } catch (SQLException ex) {
            Logger.getLogger(EtudiantDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }

    @Override
    public Etudiant selectByDate(Date annee) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    @Override
    public Etudiant selectByLibelle(String libelle) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
