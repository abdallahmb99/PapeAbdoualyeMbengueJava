/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import modeles.Etudiant;
import modeles.Personne;
import modeles.Professeur;

/**
 *
 * @author user
 */
public class PersonneDao implements IDao<Personne> {
    
    private MysqlDB mysql;
     
     private final String SQL_INSERT="INSERT INTO `personne` (`id`, `nom`, `prenom`, `datenaissance`, `numero`, `type`, `tuteur`, `grade`) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?);";
     private final String SQL_BY_NUM="Select * From Personne where numero =? ";

    public PersonneDao() {
        mysql=new MysqlDB();
    }
     
    @Override
    public int create(Personne obj) {
         throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean update(Personne obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Personne> selectAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Personne selectByNumero(String numero) {
               throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.

    }

    @Override
    public Personne selectByDate(Date annee) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    @Override
    public Personne selectByLibelle(String libelle) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   

    
    
}
