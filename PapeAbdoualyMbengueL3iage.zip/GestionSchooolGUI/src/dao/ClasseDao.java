/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import modeles.Classe;

/**
 *
 * @author user
 */
public class ClasseDao implements IDao<Classe> {

     private MysqlDB mysql;
     
     private final String SQL_INSERT="INSERT INTO `classe` (`id`, `libelle`) VALUES (NULL, ?)";
     private final String SQL_ALL="Select * From classe ";
     private final String SQL_BY_LIBELLE="Select * From classe where libelle =? ";

    public ClasseDao() {
        mysql=new MysqlDB();
    }
     
     
     
     
     
    @Override
    public int create(Classe obj) {
        int result=0;
        try {
           mysql.initPS(SQL_INSERT);
            
            mysql.getPstm().setString(1, obj.getLibelle());
            mysql.executeMaj();
              
              ResultSet rs=mysql.getPstm().getGeneratedKeys();
              if(rs.first())  result=rs.getInt(1);
             
            
       
        } catch (SQLException ex) {
            Logger.getLogger(ClasseDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    @Override
    public boolean update(Classe obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Classe> selectAll() {
        ArrayList<Classe> classes= null;
         try {
             classes=new ArrayList<Classe>(); 
            //PreparedStatement ps = cnx.prepareStatement(requete);
            mysql.initPS(SQL_ALL);
            ResultSet rs = mysql.executeSelect();
             while(rs.next()){
                Classe classe=new Classe() ;
                classe.setId(rs.getInt("id"));
                classe.setLibelle(rs.getString("libelle"));
                
               classes.add(classe);
            }
         } catch (SQLException ex) {
             Logger.getLogger(ClasseDao.class.getName()).log(Level.SEVERE, null, ex);
         }
         return classes;

    }

    @Override
    public Classe selectByNumero(String numero) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Classe selectByDate(Date annee) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Classe selectByLibelle(String libelle) {
         try {
            //PreparedStatement ps = cnx.prepareStatement(requete);
            mysql.initPS(SQL_BY_LIBELLE);
            //ps.setString(1, numero);
            mysql.getPstm().setString(1, libelle);
            ResultSet rs = mysql.executeSelect();
            if(rs.first()){
                Classe cla = new Classe();
                cla.setId(rs.getInt("id"));
                cla.setLibelle(rs.getString("libelle"));
                
                return cla;
            }
          
        } catch (SQLException ex) {
            Logger.getLogger(ClasseDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }

    
    
}
