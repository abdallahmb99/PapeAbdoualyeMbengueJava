/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import modeles.Assembleur;

/**
 *
 * @author user
 */
public class AssembleurDao implements IDao<Assembleur>{

    private MysqlDB mysql;
    private final String SQL_ALL="Select p.nom, p.prenom, c.libelle, i.anneeScolaire From personne p , classe c , inscription i WHERE p.id=i.idEtudiant AND c.id= i.idClasse";
     
    public AssembleurDao() {
        mysql=new MysqlDB();
    }
    
    

    @Override
    public ArrayList<Assembleur> selectAll() {
          ArrayList<Assembleur> assembleurs= null;
         try {
             assembleurs=new ArrayList<Assembleur>(); 
            //PreparedStatement ps = cnx.prepareStatement(requete);
            mysql.initPS(SQL_ALL);
            ResultSet rs = mysql.executeSelect();
             while(rs.next()){
                Assembleur assemb=new Assembleur() ;
                
                assemb.setNom(rs.getString("nom"));
                assemb.setPrenom(rs.getString("prenom"));
                assemb.setClasse(rs.getString("libelle"));
                assemb.setAnneSco(rs.getString("anneeScolaire"));
                       
                
               assembleurs.add(assemb);
            }
         } catch (SQLException ex) {
             Logger.getLogger(AssembleurDao.class.getName()).log(Level.SEVERE, null, ex);
         }
         return assembleurs;

    }

    @Override
    public Assembleur selectByNumero(String numero) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Assembleur selectByDate(Date annee) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    @Override
    public Assembleur selectByLibelle(String libelle) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int create(Assembleur obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean update(Assembleur obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
