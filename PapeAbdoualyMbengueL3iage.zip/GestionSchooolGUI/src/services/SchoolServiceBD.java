/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.AssembleurDao;
import dao.ClasseDao;
import dao.DetailsDao;
import dao.EtudiantDao;
import dao.InscriptionDao;
import dao.PersonneDao;
import dao.ProfesseurDao;
import java.util.ArrayList;
import java.util.Date;
import modeles.Assembleur;
import modeles.Classe;
import modeles.Etudiant;
import modeles.Professeur;



/**
 *
 * @author user
 */
public class SchoolServiceBD implements Ischoool {
        
         private ClasseDao daoClasse;
         private DetailsDao daoDetails;
         private InscriptionDao daoInscription;
         private PersonneDao daoPersonne;
         private ProfesseurDao daoProfesseur;
         private EtudiantDao daoEtudiant;
         private AssembleurDao daoAssembleur;
        
         // Constructeur

    public SchoolServiceBD() {
        daoClasse = new ClasseDao(); 
        daoDetails = new DetailsDao();
        daoInscription =new InscriptionDao();
        daoPersonne = new PersonneDao();
        daoProfesseur = new ProfesseurDao();
        daoEtudiant = new EtudiantDao ();
        daoAssembleur = new AssembleurDao();
    }
         
         
    
    @Override
    public boolean InscrireEtudiant(Etudiant etu) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

     @Override
    public boolean AjouterEtudiant(Etudiant etu) {
       return daoEtudiant.create(etu)!=0;
    }
    
    @Override
    public ArrayList<Etudiant> listerEtudiant() {
        return daoEtudiant.selectAll();
    }

    @Override
    public ArrayList<Etudiant> listerEtudiant(Date annee) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Etudiant> listerEtudiant(String classEtu) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
      @Override
    public Etudiant RechercherEtudiant(String numeroEtudiant) {
        return daoEtudiant.selectByNumero(numeroEtudiant);
    }
    
    @Override
    public Etudiant RechercherEtudiantById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    
                                                  // PROFESSEUR
    
    @Override
    public boolean ajouterProf(Professeur Prof) {
        return daoProfesseur.create(Prof)!=0;     
    }

    @Override
    public ArrayList<Professeur> listerProfesseur() {
        return daoProfesseur.selectAll();
    }

    @Override
    public ArrayList<Professeur> listerProfesseur(String numeroProf) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Professeur rechercherProfesseur(String numeroProf) {
        return daoProfesseur.selectByNumero(numeroProf);
    }

                                        // CLASSE
    
    @Override
    public boolean ajouterClasse(Classe clas) {
          return daoClasse.create(clas)!=0;  
    }

    @Override
    public ArrayList<Classe> listerClasse() {
     return daoClasse.selectAll();
       
     }

    @Override
    public Classe rechercherClasseParLibelle(String libelle) {
       return daoClasse.selectByLibelle(libelle);
    }

    
                            //  ASSEMBLEUR
    
    
    @Override
    public ArrayList<Assembleur> listerAssembleur() {
       return daoAssembleur.selectAll();
    }

    

   

  
 
   
    
}
