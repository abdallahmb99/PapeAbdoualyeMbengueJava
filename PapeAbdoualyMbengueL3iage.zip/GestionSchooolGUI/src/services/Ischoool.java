/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.ArrayList;
import java.util.Date;
import modeles.Assembleur;
import modeles.Classe;
import modeles.Etudiant;
import modeles.Professeur;

/** 
 *
 * @author user
 */
public interface Ischoool {
    // ETUDIANT
    public boolean InscrireEtudiant(Etudiant etu);
    public boolean AjouterEtudiant (Etudiant etu);
    
    public ArrayList<Etudiant> listerEtudiant();
    public ArrayList<Etudiant> listerEtudiant(Date annee); 
    public ArrayList<Etudiant> listerEtudiant(String classEtu); 
    
    public Etudiant RechercherEtudiant (String numeroEtudiant);
    public Etudiant RechercherEtudiantById (int id);
    
    // PROF
    public boolean ajouterProf(Professeur Prof);  // innterface 2
    
    public ArrayList<Professeur> listerProfesseur();
    public ArrayList<Professeur> listerProfesseur(String numeroProf); 
    
    public Professeur rechercherProfesseur(String numeroProf);
    
    
    
    // CLASSE
   public boolean ajouterClasse(Classe clas);
   public ArrayList<Classe> listerClasse();
   public Classe rechercherClasseParLibelle (String libelle);
   
   // ASSEMBLEUR
   public ArrayList<Assembleur> listerAssembleur();
}
