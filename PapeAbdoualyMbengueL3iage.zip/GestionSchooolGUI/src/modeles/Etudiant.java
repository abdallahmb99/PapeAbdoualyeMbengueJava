/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeles;

/**
 *
 * @author user
 */
public class Etudiant extends Personne  {
    private String tuteur;
    
    // Navigation
    private Inscription [] inscriptions;
    
    // Constructeur

    public Etudiant() {
        super();
      
        type="Etudiant";
    }
    
    // getters

    public String getTuteur() {
        return tuteur;
    }

    public Inscription[] getInscriptions() {
        return inscriptions;
    }
    
    
    // setters

    public void setTuteur(String tuteur) {
        this.tuteur = tuteur;
    }

    public void setInscriptions(Inscription[] inscriptions) {
        this.inscriptions = inscriptions;
    }

  
    
    
    
    
}
