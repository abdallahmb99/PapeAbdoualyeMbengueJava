/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeles;

/**
 *
 * @author user
 */
public class Professeur extends Personne  {
    private String grade;
    
    // Navigation
    private Classe [] classes;
    private Detail detail;
    
    
    // Constructeur

    public Professeur() {
        super();

        type="professeur";
    }
    
    // getters

    public String getGrade() {
        return grade;
    }
    
   

    public Classe[] getClasses() {
        return classes;
    }
    
    
    // setters

    public void setGrade(String grade) {
        this.grade = grade;
    }

 
    public void setClasses(Classe[] classes) {
        this.classes = classes;
    }

    

 
    
}
