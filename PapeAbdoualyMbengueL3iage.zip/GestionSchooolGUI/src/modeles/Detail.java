/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeles;

/**
 *
 * @author user
 */
class Detail {
    private String anneeScolaire;
    
    // navigation
    
    private Professeur [] professeurs;
    private Classe [] classes;
    
    // constructeur

    public Detail() {
    }

    // getters

    public String getAnneeScolaire() {
        return anneeScolaire;
    }

    public Professeur[] getProfesseurs() {
        return professeurs;
    }

    public Classe[] getClasses() {
        return classes;
    }
    
    // setters

    public void setAnneeScolaire(String anneeScolaire) {
        this.anneeScolaire = anneeScolaire;
    }

    public void setProfesseurs(Professeur[] professeurs) {
        this.professeurs = professeurs;
    }

    public void setClasses(Classe[] classes) {
        this.classes = classes;
    }
    
    
    
}
