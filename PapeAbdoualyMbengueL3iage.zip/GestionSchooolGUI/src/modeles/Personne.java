/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeles;

import java.util.Date;

/**
 *
 * @author user
 */
public abstract class Personne {
    protected int id;
    protected String nom;
    protected String prenom;
    protected Date datenaiss;
    protected String numero;
    protected String type;
    private static int cpt; // Compteur
    // constructeur

    public Personne() {
        cpt ++;
        id= cpt;
    }

    public Personne(String nom, String prenom, Date datenaiss, String numero) {
        id=++cpt;
        this.nom = nom;
        this.prenom = prenom;
        this.datenaiss = datenaiss;
        this.numero = numero;
    }
    
    
    // getters

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public Date getDatenaiss() {
        return datenaiss;
    }

    public String getNumero() {
        return numero;
    }

    public String getType() {
        return type;
    }

    
    
    
    // setters

    public void setId(int id) {
        this.id = id;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setDatenaiss(Date datenaiss) {
        this.datenaiss = datenaiss;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Personne{" + "id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", datenaiss=" + datenaiss + ", numero=" + numero + ", type=" + type + '}';
    }
    


   

    
    
    
}
