/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeles;

/**
 *
 * @author user
 */
public class Classe {
    private int id;
    private String libelle;
     private static int cpt; // Compteur
    
    
    // Navigation
    private Inscription [] inscriptions;
    private Professeur [] professeurs;
    private Detail detail; 
    
    // Construction

    public Classe() {
        cpt++;
        id=cpt;
    }    

    public Classe(String libelle) {
        id=++cpt;
        this.libelle = libelle;
    }

    

    // getters
    
    public int getId() {
        return id;
    }

    public String getLibelle() {
        return libelle;
    }

    public Inscription[] getInscriptions() {
        return inscriptions;
    }

    public Professeur[] getProfesseurs() {
        return professeurs;
    }

    public static int getCpt() {
        return cpt;
    }
    
    
    // Setters

    public void setId(int id) {
        this.id = id;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public void setInscriptions(Inscription[] inscriptions) {
        this.inscriptions = inscriptions;
    }

    public void setProfesseurs(Professeur[] professeurs) {
        this.professeurs = professeurs;
    }
    
    // toString

    @Override
    public String toString() {
        return libelle;
    }
    
    
    
    
}
