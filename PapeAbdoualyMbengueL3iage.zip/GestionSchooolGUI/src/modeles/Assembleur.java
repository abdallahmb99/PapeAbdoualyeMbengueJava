/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeles;

/**
 *
 * @author user
 */
public class Assembleur {
    private String nom;
    private String prenom;
    private String classe;
    private String anneSco;

    public Assembleur() {
    }
    
    // GETTERS

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getClasse() {
        return classe;
    }

    public String getAnneSco() {
        return anneSco;
    }
    
    // SETTERS

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }

    public void setAnneSco(String anneSco) {
        this.anneSco = anneSco;
    }

    @Override
    public String toString() {
        return "Assembleur{" + "nom=" + nom + ", prenom=" + prenom + ", classe=" + classe + ", anneSco=" + anneSco + '}';
    }
    
    
    
}
