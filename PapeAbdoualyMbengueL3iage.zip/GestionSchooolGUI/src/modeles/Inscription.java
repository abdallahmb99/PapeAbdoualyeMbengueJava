/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeles;

import java.util.Date;

/**
 *
 * @author user
 */
public class Inscription {
      private Date date;
    private Date anneeScol;
    
    
    // Navigation
    private Etudiant etudiant;
    private Classe classe;

    // constructeur
    public Inscription() {
    }
    
    // getters

    public Date getDate() {
        return date;
    }

    public Date getAnneeScol() {
        return anneeScol;
    }

    public Etudiant getEtudiant() {
        return etudiant;
    }

    public Classe getClasse() {
        return classe;
    }
    
    // setters

    public void setDate(Date date) {
        this.date = date;
    }

    public void setAnneeScol(Date anneeScol) {
        this.anneeScol = anneeScol;
    }

    public void setEtudiant(Etudiant etudiant) {
        this.etudiant = etudiant;
    }

    public void setClasse(Classe classe) {
        this.classe = classe;
    }

    public void setAnneeScol(String annee) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
}
